
export interface Differential {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: string;
  tag: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  summary: string;
  highlights: string[];
  recommendedFor: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}
