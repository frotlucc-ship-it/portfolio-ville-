import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { About } from './components/About';
import { Differentials } from './components/Differentials';
import { Services } from './components/Services';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { ContactForm } from './components/ContactForm';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';

export default function App() {
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('ville-theme');
      if (savedTheme) {
        return savedTheme === 'dark';
      }
    }
    return true; // Default to sleek dark mode
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('ville-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('ville-theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark(prev => !prev);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#0c0e14] text-neutral-900 dark:text-neutral-100 transition-colors duration-200 selection:bg-neutral-700 selection:text-white font-sans antialiased">
      {/* Top Bar adhering to 3-zone contract */}
      <Navbar isDark={isDark} toggleTheme={toggleTheme} />

      <main>
        {/* Seção Inicial Impactante (Tagline + Value Prop + CTA WhatsApp) */}
        <Hero />

        {/* Estatísticas (8 meses, +70 estabelecimentos, 2h entrega, 100% satisfação) */}
        <Stats />

        {/* Sobre / Quem Somos */}
        <About />

        {/* Diferenciais Competitivos (Atendimento humanizado, Entrega 2h, Diversidade de Nichos, Satisfação) */}
        <Differentials />

        {/* Serviços para Todos os Nichos */}
        <Services />

        {/* Prova Social & Depoimentos */}
        <Testimonials />

        {/* Perguntas Frequentes (FAQ) */}
        <FAQ />

        {/* Formulário de Contato com Envio Direto ao WhatsApp */}
        <ContactForm />
      </main>

      {/* Floating WhatsApp Action Button with status tooltip */}
      <FloatingWhatsApp />

      {/* Rodapé Minimalista */}
      <Footer />
    </div>
  );
}
