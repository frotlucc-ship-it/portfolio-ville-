import { useState } from 'react';
import { MessageCircle, X, ArrowUpRight } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_FORMATTED } from '../data/content';

export function FloatingWhatsApp() {
  const [showTooltip, setShowTooltip] = useState(true);

  return (
    <aside aria-label="Atendimento via WhatsApp" className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2 pointer-events-none">
      {/* Interactive Tooltip bubble */}
      {showTooltip && (
        <div className="pointer-events-auto bg-neutral-900 text-white p-3.5 rounded-2xl shadow-2xl border border-neutral-800 max-w-xs animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs text-neutral-200 font-bold">
                <span className="w-2 h-2 rounded-full bg-neutral-300 animate-pulse" />
                <span>Ville studio Online</span>
              </div>
              <p className="text-xs text-neutral-300 leading-snug">
                Olá! Precisa de um site moderno entregue em até 2 horas?
              </p>
            </div>
            <button
              onClick={() => setShowTooltip(false)}
              aria-label="Fechar aviso"
              className="text-neutral-500 hover:text-neutral-300 p-0.5 rounded transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <a
            href={getWhatsAppUrl('Olá, Ville studio! Gostaria de um orçamento rápido pelo WhatsApp.')}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2.5 flex items-center justify-between text-xs font-bold text-neutral-950 bg-neutral-200 hover:bg-white py-1.5 px-3 rounded-lg transition-colors"
          >
            <span>Conversar agora</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>
      )}

      {/* Floating Action Button */}
      <a
        href={getWhatsAppUrl('Olá, Ville studio! Gostaria de solicitar um orçamento no WhatsApp.')}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Solicitar orçamento no WhatsApp ${WHATSAPP_FORMATTED}`}
        className="pointer-events-auto flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] text-white shadow-[0_4px_25px_rgba(37,211,102,0.45)] hover:scale-106 active:scale-95 transition-all focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-white group"
      >
        <MessageCircle className="w-7 h-7 fill-white stroke-none" />
      </a>
    </aside>
  );
}
