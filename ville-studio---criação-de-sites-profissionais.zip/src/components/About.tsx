import { CheckCircle2, ArrowUpRight, Sparkles } from 'lucide-react';
import { getWhatsAppUrl } from '../data/content';

export function About() {
  const commitments = [
    'Design minimalista pensado exclusivamente para gerar orçamentos e vendas',
    'Entrega express com sites prontos para veicular no mesmo dia',
    'Atendimento direto e sem intermediários com o especialista do seu projeto',
    'Adequação técnica completa para smartphones, tablets e desktops',
    'Presença digital sólida com atendimento nacional e internacional'
  ];

  return (
    <section id="sobre" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Story & Mission */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              <Sparkles className="w-4 h-4" />
              <span>Sobre a Ville studio</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white leading-tight [text-wrap:balance]">
              Construímos a autoridade digital que o seu negócio merece.
            </h2>

            <div className="space-y-4 text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed">
              <p>
                Há <strong>8 meses no mercado</strong>, a Ville studio nasceu com uma missão clara: eliminar a lentidão, as barreiras técnicas e a burocracia que impedem empresas de terem uma presença online impecável.
              </p>
              <p>
                Já atendemos <strong>mais de 70 estabelecimentos</strong> nos mais variados nichos — de restaurantes a clínicas médicas, advogados, comércios locais e profissionais autônomos. Desenvolvemos sites que combinam sofisticação estética minimalista, clareza na mensagem e velocidade máxima de carregamento.
              </p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                Com base no Brasil e alcance global, proporcionamos um atendimento próximo e personalizado para empresas que buscam resultados tangíveis no ambiente digital.
              </p>
            </div>

            <div className="pt-2 space-y-3">
              {commitments.map((item, idx) => (
                <div key={idx} className="flex items-start gap-3 text-sm sm:text-base text-neutral-800 dark:text-neutral-200">
                  <CheckCircle2 className="w-5 h-5 text-neutral-600 dark:text-neutral-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <a
                href={getWhatsAppUrl('Olá! Quero conhecer mais sobre a Ville studio e solicitar um orçamento.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-neutral-950 bg-neutral-200 hover:bg-white active:bg-neutral-300 dark:bg-white dark:hover:bg-neutral-200 dark:text-neutral-950 rounded-lg transition-all shadow-md"
              >
                <span>Falar com o Especialista</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Right Column: Mission Card & Value Stack */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-8 rounded-2xl bg-neutral-100 dark:bg-neutral-900/90 border border-neutral-200 dark:border-neutral-800 space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                  Nosso Propósito
                </span>
                <h3 className="text-xl font-bold text-neutral-900 dark:text-white">
                  Transformar visitantes em clientes qualificados
                </h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  Não criamos sites apenas para serem "bonitos". Cada botão, texto, imagem e tempo de carregamento é milimetricamente estruturado para conduzir o usuário ao seu WhatsApp de forma natural e sem atrito.
                </p>
              </div>

              <div className="border-t border-neutral-200 dark:border-neutral-800 pt-6 space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600 dark:text-neutral-400">Tempo médio de resposta</span>
                  <span className="font-mono font-semibold text-neutral-900 dark:text-white tabular-nums">Menos de 15 min</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600 dark:text-neutral-400">Prazo de entrega express</span>
                  <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-100 tabular-nums">A partir de 2 horas</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600 dark:text-neutral-400">Abrangência de atendimento</span>
                  <span className="font-mono font-semibold text-neutral-900 dark:text-white">Nacional e Internacional</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-neutral-600 dark:text-neutral-400">Avaliações positivas</span>
                  <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-100 tabular-nums">5.0 / 5.0 estrelas</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
