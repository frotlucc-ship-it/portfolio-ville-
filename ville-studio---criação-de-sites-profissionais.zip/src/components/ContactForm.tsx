import { useState } from 'react';
import { Send, CheckCircle2, MessageSquare, PhoneCall, Clock, Globe } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_FORMATTED, WHATSAPP_NUMBER } from '../data/content';

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    business: '',
    phone: '',
    niche: 'Geral / Outro',
    urgency: 'Hoje (Entrega em até 2 horas)',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (errorMsg) setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMsg('Por favor, preencha seu nome e seu WhatsApp para que possamos te responder.');
      return;
    }

    const compiledMessage = `Olá, Ville studio! Meu nome é ${formData.name} (${formData.business || 'Negócio próprio'}).
• WhatsApp: ${formData.phone}
• Nicho: ${formData.niche}
• Urgência: ${formData.urgency}
• Mensagem: ${formData.message || 'Gostaria de solicitar um orçamento para meu novo site.'}

Aguardo o retorno de vocês!`;

    const targetUrl = getWhatsAppUrl(compiledMessage);
    setSubmitted(true);

    // Open WhatsApp after brief user feedback
    setTimeout(() => {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
    }, 400);
  };

  return (
    <section id="contato" className="py-20 md:py-28 bg-neutral-100/60 dark:bg-neutral-900/30 border-t border-neutral-200 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Direct info & Trust */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Fale com a Ville studio
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
              Pronto para transformar sua presença digital?
            </h2>
            <p className="text-base text-neutral-600 dark:text-neutral-300 leading-relaxed">
              Preencha o formulário para enviar os detalhes do seu projeto ou fale conosco diretamente no WhatsApp. Nosso atendimento é humanizado, sem robôs e com resposta em minutos.
            </p>

            <div className="space-y-4 pt-4 border-t border-neutral-200 dark:border-neutral-800">
              <div className="flex items-center gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white">WhatsApp Oficial</div>
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline font-mono text-neutral-800 dark:text-neutral-200 font-semibold"
                  >
                    {WHATSAPP_FORMATTED}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white">Tempo de Criação</div>
                  <div>Entrega express em até 2 horas</div>
                </div>
              </div>

              <div className="flex items-center gap-3 text-sm text-neutral-700 dark:text-neutral-300">
                <div className="p-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white">Área de Atendimento</div>
                  <div>Brasil e clientes internacionais</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xl text-left">
              {submitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-14 h-14 mx-auto rounded-full bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-white flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
                    Solicitação Encaminhada!
                  </h3>
                  <p className="text-sm text-neutral-600 dark:text-neutral-300 max-w-md mx-auto">
                    Seu formulário foi pré-formatado e o WhatsApp da Ville studio está sendo aberto para darmos sequência imediatamente.
                  </p>
                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="text-xs font-semibold text-neutral-600 dark:text-neutral-400 underline hover:text-neutral-900 dark:hover:text-white"
                    >
                      Enviar outra solicitação
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div className="space-y-1.5">
                      <label htmlFor="name" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                        Seu Nome *
                      </label>
                      <input
                        id="name"
                        type="text"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Ex: Lucca Silva"
                        className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label htmlFor="business" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                        Nome do seu Negócio / Marca
                      </label>
                      <input
                        id="business"
                        type="text"
                        name="business"
                        value={formData.business}
                        onChange={handleChange}
                        placeholder="Ex: Clínica Bem Estar"
                        className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div className="space-y-1.5">
                      <label htmlFor="phone" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                        WhatsApp com DDD *
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Ex: (11) 99883-7294"
                        className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label htmlFor="niche" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                        Segmento / Nicho
                      </label>
                      <select
                        id="niche"
                        name="niche"
                        value={formData.niche}
                        onChange={handleChange}
                        className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400"
                      >
                        <option value="Gastronomia / Restaurante">Gastronomia / Restaurante</option>
                        <option value="Saúde / Clínica / Estética">Saúde / Clínica / Estética</option>
                        <option value="Advocacia / Jurídico">Advocacia / Jurídico</option>
                        <option value="Imobiliária / Corretores">Imobiliária / Corretores</option>
                        <option value="Comércio / Loja Física">Comércio / Loja Física</option>
                        <option value="Barbearia / Beleza">Barbearia / Beleza</option>
                        <option value="Prestador de Serviços">Prestador de Serviços</option>
                        <option value="Outro segmento">Outro segmento</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="urgency" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                      Urgência de Entrega
                    </label>
                    <select
                      id="urgency"
                      name="urgency"
                      value={formData.urgency}
                      onChange={handleChange}
                      className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400"
                    >
                      <option value="Hoje (Entrega express em até 2 horas)">Hoje (Entrega express em até 2 horas)</option>
                      <option value="Nos próximos 2 a 3 dias">Nos próximos 2 a 3 dias</option>
                      <option value="Sem pressa / Planejamento">Sem pressa / Planejamento</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="message" className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                      Mensagem ou Detalhes do Projeto
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={3}
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Conte um pouco sobre o que você deseja para o seu site..."
                      className="w-full px-4 py-3 text-sm bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-neutral-400 resize-none"
                    />
                  </div>

                  {errorMsg && (
                    <div className="text-xs font-medium text-red-500 bg-red-500/10 p-3 rounded-lg border border-red-500/20">
                      {errorMsg}
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-4 px-6 text-sm font-bold text-neutral-950 bg-neutral-200 hover:bg-white active:bg-neutral-300 dark:bg-white dark:hover:bg-neutral-200 dark:text-neutral-950 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-400"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>Enviar e Solicitar Orçamento no WhatsApp</span>
                    <Send className="w-4 h-4 ml-1" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
