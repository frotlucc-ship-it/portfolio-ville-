import { Star } from 'lucide-react';
import { TESTIMONIALS } from '../data/content';

export function Testimonials() {
  return (
    <section className="py-20 md:py-28 bg-white dark:bg-neutral-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16 text-left">
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 mb-2">
            Prova Social & Depoimentos
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            O que dizem os estabelecimentos que atendemos.
          </h2>
          <p className="mt-4 text-base text-neutral-600 dark:text-neutral-300">
            Mais de 70 negócios já transformaram sua presença digital com a velocidade e o cuidado humanizado da Ville studio.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <div
              key={idx}
              className="p-8 rounded-2xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 flex flex-col justify-between space-y-6"
            >
              <div className="space-y-4">
                <div className="flex items-center gap-1 text-neutral-400 dark:text-neutral-300">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-neutral-400 text-neutral-400 dark:fill-neutral-300 dark:text-neutral-300" />
                  ))}
                </div>
                <p className="text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed italic">
                  "{t.text}"
                </p>
              </div>

              <div className="border-t border-neutral-200 dark:border-neutral-800 pt-4">
                <div className="font-bold text-sm text-neutral-900 dark:text-white">
                  {t.name}
                </div>
                <div className="text-xs text-neutral-500 dark:text-neutral-400">
                  {t.role} · <span className="text-neutral-700 dark:text-neutral-300 font-medium">{t.business}</span>
                </div>
                <div className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                  {t.location}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
