import { Zap, MessageSquareHeart, Layers, ShieldCheck, ArrowRight } from 'lucide-react';
import { DIFFERENTIALS, getWhatsAppUrl } from '../data/content';

export function Differentials() {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Zap':
        return <Zap className="w-6 h-6 text-neutral-700 dark:text-neutral-200" />;
      case 'MessageSquareHeart':
        return <MessageSquareHeart className="w-6 h-6 text-neutral-700 dark:text-neutral-200" />;
      case 'Layers':
        return <Layers className="w-6 h-6 text-neutral-700 dark:text-neutral-200" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-neutral-700 dark:text-neutral-200" />;
      default:
        return <Zap className="w-6 h-6 text-neutral-700 dark:text-neutral-200" />;
    }
  };

  return (
    <section id="diferenciais" className="py-20 md:py-28 bg-neutral-100/60 dark:bg-neutral-900/30 border-y border-neutral-200 dark:border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16 text-left">
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 mb-2">
            Por que escolher a Ville studio
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            Diferenciais competitivos que aceleram o seu faturamento.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            Enquanto agências tradicionais demoram semanas e cobram valores exorbitantes, entregamos velocidade recorde com acabamento de alto nível.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {DIFFERENTIALS.map((diff, index) => {
            const isMarquee = diff.id === 'express-delivery';
            return (
              <div
                key={diff.id}
                className={`p-8 rounded-2xl border transition-all duration-300 ${
                  isMarquee
                    ? 'bg-neutral-900 text-white border-neutral-700 shadow-[0_10px_30px_rgba(0,0,0,0.25)] ring-1 ring-neutral-700/50'
                    : 'bg-white dark:bg-neutral-900/70 text-neutral-900 dark:text-white border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between mb-6">
                  <div className={`p-3 rounded-xl ${isMarquee ? 'bg-neutral-800 border border-neutral-700' : 'bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700'}`}>
                    {getIcon(diff.iconName)}
                  </div>
                  <span className="text-xs font-mono font-medium text-neutral-500 dark:text-neutral-400">
                    0{index + 1}
                  </span>
                </div>

                <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2">
                  {diff.tag}
                </div>

                <h3 className={`text-xl sm:text-2xl font-bold mb-2 ${isMarquee ? 'text-white' : 'text-neutral-900 dark:text-white'}`}>
                  {diff.title}
                </h3>

                <p className={`text-sm font-medium mb-3 ${isMarquee ? 'text-neutral-300' : 'text-neutral-700 dark:text-neutral-300'}`}>
                  {diff.subtitle}
                </p>

                <p className={`text-sm leading-relaxed ${isMarquee ? 'text-neutral-300' : 'text-neutral-600 dark:text-neutral-400'}`}>
                  {diff.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Quick CTA strip */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-neutral-900 border border-neutral-800 text-white flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="text-lg font-bold">Precisa do seu site no ar ainda hoje?</h4>
            <p className="text-xs sm:text-sm text-neutral-400">
              Converse agora mesmo com nosso time e ative sua presença digital em poucas horas.
            </p>
          </div>
          <a
            href={getWhatsAppUrl('Olá! Quero aproveitar a entrega express de 2 horas da Ville studio.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-bold text-neutral-950 bg-neutral-200 hover:bg-white active:bg-neutral-300 dark:bg-white dark:hover:bg-neutral-200 dark:text-neutral-950 rounded-lg transition-all whitespace-nowrap shrink-0 shadow-md"
          >
            <span>Iniciar Projeto Agora</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
