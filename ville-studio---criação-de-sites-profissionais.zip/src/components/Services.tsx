import { Check, ArrowUpRight } from 'lucide-react';
import { SERVICES, getWhatsAppUrl } from '../data/content';

export function Services() {
  return (
    <section id="servicos" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16 text-left">
          <div className="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400 mb-2">
            Nossos Serviços
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white [text-wrap:balance]">
            Criação de sites sob medida para todos os nichos.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-neutral-600 dark:text-neutral-300">
            Cada negócio possui uma dinâmica única. Desenvolvemos a estrutura ideal para captar a atenção do seu cliente e transformá-la em contato direto no WhatsApp.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SERVICES.map((service, index) => (
            <div
              key={service.id}
              className="p-8 rounded-2xl bg-white dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700 transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
                    Modalidade 0{index + 1}
                  </span>
                  <span className="text-xs font-medium text-neutral-600 dark:text-neutral-300">
                    {service.recommendedFor}
                  </span>
                </div>

                <h3 className="text-2xl font-bold text-neutral-900 dark:text-white">
                  {service.title}
                </h3>

                <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                  {service.summary}
                </p>

                <div className="pt-2 space-y-2.5">
                  {service.highlights.map((item, hIdx) => (
                    <div key={hIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700 dark:text-neutral-300">
                      <Check className="w-4 h-4 text-neutral-600 dark:text-neutral-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-neutral-100 dark:border-neutral-800/80 mt-6">
                <a
                  href={getWhatsAppUrl(`Olá, Ville studio! Gostaria de um orçamento para o serviço: ${service.title}.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-neutral-900 dark:text-white hover:text-neutral-500 dark:hover:text-neutral-300 transition-colors group"
                >
                  <span>Solicitar orçamento para este serviço</span>
                  <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
