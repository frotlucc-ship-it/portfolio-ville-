import { ArrowUpRight, MessageCircle, Download } from 'lucide-react';
import { getWhatsAppUrl, WHATSAPP_FORMATTED } from '../data/content';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-neutral-950 text-neutral-400 border-t border-neutral-800/80 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 text-left">
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <a href="#" className="text-xl font-bold tracking-tight text-white inline-block">
              <span>Ville<span className="text-neutral-400 font-medium"> studio</span></span>
            </a>
            <p className="text-sm text-neutral-400 max-w-sm leading-relaxed">
              Sua presença digital começa com a gente. Há 8 meses criando sites modernos e de alta conversão para empresas e profissionais de todos os nichos.
            </p>
            <div className="text-xs text-neutral-500">
              Atendimento em todo o Brasil e clientes internacionais.
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
              Navegação
            </div>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => handleNavClick('#sobre')}
                  className="hover:text-white transition-colors"
                >
                  Sobre a Ville studio
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('#diferenciais')}
                  className="hover:text-white transition-colors"
                >
                  Diferenciais Competitivos
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('#servicos')}
                  className="hover:text-white transition-colors"
                >
                  Serviços por Nicho
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('#contato')}
                  className="hover:text-white transition-colors"
                >
                  Fale Conosco
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold">
              Contato Direto
            </div>
            <p className="text-sm text-neutral-400">
              Pronto para criar seu site com entrega a partir de 2 horas? Fale agora mesmo com nossa equipe.
            </p>
            <div className="pt-2">
              <a
                href={getWhatsAppUrl('Olá, Ville studio! Gostaria de conversar com você sobre um novo site.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-neutral-950 bg-neutral-200 hover:bg-white rounded-lg transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp: {WHATSAPP_FORMATTED}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-neutral-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            © {currentYear} Ville studio. Todos os direitos reservados.
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href="/ville-studio.zip"
              download="ville-studio.zip"
              className="inline-flex items-center gap-1.5 text-neutral-300 hover:text-white underline underline-offset-4 transition-colors font-medium"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Baixar Projeto (.ZIP)</span>
            </a>
            <span aria-hidden="true">·</span>
            <a
              href="/ville-studio-dist.zip"
              download="ville-studio-dist.zip"
              className="inline-flex items-center gap-1.5 text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              <span>Netlify Drop (.ZIP)</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
