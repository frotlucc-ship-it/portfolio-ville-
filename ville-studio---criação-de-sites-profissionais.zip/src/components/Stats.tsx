import { STATS } from '../data/content';

export function Stats() {
  return (
    <section className="py-12 border-y border-neutral-200 dark:border-neutral-800/80 bg-neutral-100/50 dark:bg-neutral-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {STATS.map((stat, index) => (
            <div key={index} className="space-y-2 text-left">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 dark:text-white font-mono tabular-nums">
                <span className="text-neutral-800 dark:text-neutral-100">{stat.value}</span>
              </div>
              <div className="text-sm sm:text-base font-bold text-neutral-800 dark:text-neutral-100">
                {stat.label}
              </div>
              <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 leading-snug">
                {stat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
