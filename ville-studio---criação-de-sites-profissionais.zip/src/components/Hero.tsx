import { ArrowUpRight, MessageCircle, Clock, ShieldCheck, Globe2 } from 'lucide-react';
import { getWhatsAppUrl, HERO_IMAGE } from '../data/content';

export function Hero() {
  const handleScrollToServices = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.querySelector('#servicos');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative overflow-hidden pt-12 pb-20 md:pt-20 md:pb-28">
      {/* Background subtle radial gradient */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-neutral-400/10 dark:bg-neutral-600/15 blur-[130px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Typography & Conversion Action */}
          <div className="lg:col-span-6 space-y-6 text-left">
            {/* Tagline & Clean Metadata Indicator */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              <span>Ville studio</span>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span>Criação de Sites para Todos os Nichos</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-white leading-[1.08] [text-wrap:balance]">
              Sua presença digital começa <span className="text-neutral-500 dark:text-neutral-400">com a gente.</span>
            </h1>

            {/* Subtitle / Value Proposition */}
            <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-xl">
              Criamos sites modernos, ultra-rápidos e sob medida para empresas, negócios locais e profissionais autônomos. Entrega recorde a partir de <strong className="text-neutral-900 dark:text-white font-semibold">2 horas</strong> com atendimento 100% humanizado e alcance nacional e internacional.
            </p>

            {/* Metadata Line (Zero-pill discipline with typographical separators) */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 pt-1">
              <span className="inline-flex items-center gap-1.5 text-neutral-800 dark:text-neutral-200">
                <Clock className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
                Entrega express em até 2h
              </span>
              <span aria-hidden="true" className="text-neutral-400">·</span>
              <span className="inline-flex items-center gap-1.5 text-neutral-800 dark:text-neutral-200">
                <Globe2 className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
                Brasil e Exterior
              </span>
              <span aria-hidden="true" className="text-neutral-400">·</span>
              <span className="inline-flex items-center gap-1.5 text-neutral-800 dark:text-neutral-200">
                <ShieldCheck className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
                +70 clientes satisfeitos
              </span>
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={getWhatsAppUrl('Olá! Quero solicitar um orçamento para o meu site com a Ville studio.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm sm:text-base font-bold text-neutral-950 bg-neutral-200 hover:bg-white active:bg-neutral-300 dark:bg-white dark:hover:bg-neutral-200 dark:text-neutral-950 rounded-lg transition-all shadow-[0_0_25px_rgba(255,255,255,0.15)] whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowUpRight className="w-5 h-5" />
              </a>

              <a
                href="#servicos"
                onClick={handleScrollToServices}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm sm:text-base font-semibold text-neutral-800 dark:text-neutral-200 hover:text-neutral-950 dark:hover:text-white bg-neutral-100 dark:bg-neutral-900/80 hover:bg-neutral-200 dark:hover:bg-neutral-800 border border-neutral-300 dark:border-neutral-800 rounded-lg transition-colors whitespace-nowrap"
              >
                <span>Conhecer Serviços</span>
              </a>
            </div>
          </div>

          {/* Right Column: Visual Focal Carrier Mockup */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl bg-neutral-950 group">
              <img
                src={HERO_IMAGE}
                alt="Ville studio - Mockup de sites modernos em múltiplos dispositivos"
                referrerPolicy="no-referrer"
                className="w-full h-auto aspect-16/9 object-cover transition-transform duration-500 group-hover:scale-102"
              />
              {/* Subtle glass reflection overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-neutral-300 backdrop-blur-md bg-neutral-950/70 p-3 rounded-lg border border-neutral-800">
                <span className="font-medium text-white">Sites de alta conversão para o seu nicho</span>
                <span className="font-mono tabular-nums text-neutral-400">Design responsivo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
