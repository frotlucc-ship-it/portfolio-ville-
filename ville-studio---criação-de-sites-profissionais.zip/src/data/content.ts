import { Differential, ServiceItem, FAQItem } from '../types';

export const WHATSAPP_NUMBER = '5511998837294';
export const WHATSAPP_FORMATTED = '+55 (11) 99883-7294';

export const getWhatsAppUrl = (message?: string): string => {
  const defaultText = 'Olá, Ville studio! Gostaria de solicitar um orçamento para o meu site.';
  const encoded = encodeURIComponent(message || defaultText);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;
};

export const HERO_IMAGE = '/src/assets/images/ville_hero_mockup_1794289016639.jpg';

export const STATS = [
  {
    value: '8+',
    label: 'Meses no mercado',
    description: 'Crescimento ágil e consistente construindo marcas no digital'
  },
  {
    value: '+70',
    label: 'Estabelecimentos atendidos',
    description: 'Negócios locais, empresas e autônomos impulsionados'
  },
  {
    value: '2h',
    label: 'Entrega expressa recorde',
    description: 'Criação e publicação ágil para quem não pode perder vendas'
  },
  {
    value: '100%',
    label: 'Foco na sua satisfação',
    description: 'Atendimento humanizado em todo o Brasil e exterior'
  }
];

export const DIFFERENTIALS: Differential[] = [
  {
    id: 'express-delivery',
    title: 'Criação e entrega em até 2 horas',
    subtitle: 'Velocidade extrema sem abrir mão de design refinado',
    description: 'Seu negócio não pode esperar dias ou semanas. Com nosso fluxo de trabalho otimizado e arquitetura modular de alta performance, colocamos seu site no ar no mesmo dia, pronto para converter.',
    iconName: 'Zap',
    tag: 'Diferencial Exclusivo'
  },
  {
    id: 'humanized-service',
    title: 'Atendimento 100% humanizado',
    subtitle: 'Conversa direta com quem realmente cria seu projeto',
    description: 'Nada de robôs impessoais ou chamados burocráticos. Você conversa diretamente com nossos especialistas pelo WhatsApp, alinhando cada detalhe da sua marca com atenção total.',
    iconName: 'MessageSquareHeart',
    tag: 'Proximidade Real'
  },
  {
    id: 'multi-niche',
    title: 'Diversidade total de nichos',
    subtitle: 'Solução sob medida para qualquer segmento de mercado',
    description: 'De restaurantes e consultórios médicos a escritórios de advocacia, estabelecimentos comerciais, barbearias e prestadores de serviço. Criamos a linguagem visual ideal para o seu público.',
    iconName: 'Layers',
    tag: 'Flexibilidade Total'
  },
  {
    id: 'satisfaction-first',
    title: 'Sua satisfação em primeiro lugar',
    subtitle: 'Compromisso com o resultado e a estética do seu negócio',
    description: 'Não entregamos apenas código: entregamos uma ferramenta viva de vendas e credibilidade. Acompanhamos ajustes e refinamentos até o projeto refletir a sua essência com maestria.',
    iconName: 'ShieldCheck',
    tag: 'Garantia Ville'
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'custom-sites',
    title: 'Criação de Sites para Empresas e Negócios',
    summary: 'Sites modernos e sob medida com foco na apresentação impecável da sua marca e conversão direta no WhatsApp.',
    highlights: [
      'Estrutura moderna e minimalista pensada para o seu público',
      'Integração direta com o seu WhatsApp e canais de contato',
      'Velocidade máxima de carregamento para não perder visitantes',
      'Layout 100% responsivo para smartphones e computadores'
    ],
    recommendedFor: 'Empresas, prestadores de serviços e empreendedores'
  },
  {
    id: 'institutional-sites',
    title: 'Sites Institucionais para Estabelecimentos',
    summary: 'Presença digital completa para estabelecer autoridade, apresentar serviços e consolidar sua marca.',
    highlights: [
      'Apresentação institucional estruturada, elegante e profissional',
      'Seções de serviços, diferenciais, localização e atendimento',
      'Otimização básica de SEO para buscas locais no Google',
      'Design limpo com tipografia marcante e alto padrão visual'
    ],
    recommendedFor: 'Clínicas, restaurantes, escritórios e estabelecimentos'
  },
  {
    id: 'redesign-sites',
    title: 'Modernização e Reformulação de Sites',
    summary: 'Reformulação visual e estrutural de sites antigos, tornando-os contemporâneos, rápidos e eficientes.',
    highlights: [
      'Renovação estética completa sem perder a identidade da marca',
      'Eliminação de lentidão e travamentos no carregamento',
      'Adaptação às telas e padrões de navegação modernos',
      'Otimização do fluxo de contato para o WhatsApp'
    ],
    recommendedFor: 'Negócios que já possuem site mas precisam se modernizar'
  },
  {
    id: 'mobile-first-sites',
    title: 'Sites Otimizados para Celular (Mobile-First)',
    summary: 'Desenvolvimento voltado prioritariamente para a experiência de quem acessa pelo smartphone.',
    highlights: [
      'Botões de contato com toque fácil e ergonômico',
      'Carregamento instantâneo mesmo em redes móveis 4G/5G',
      'Navegação fluida sem poluição visual ou elementos pesados',
      'Experiência limpa que gera credibilidade imediata'
    ],
    recommendedFor: 'Negócios com grande volume de acessos pelo celular'
  }
];

export const TESTIMONIALS = [
  {
    name: 'Carlos Mendes',
    role: 'Sócio-Fundador',
    business: 'Bistrô Sálvia & Vinho',
    text: 'Precisávamos colocar o cardápio e reservas no ar para o fim de semana. A Ville studio não apenas entregou em menos de 2 horas como o site ficou de nível internacional. O resultado em reservas no WhatsApp foi imediato.',
    location: 'São Paulo, SP'
  },
  {
    name: 'Dra. Vanessa Duarte',
    role: 'Dermatologista & Gestora',
    business: 'Instituto Harmonize',
    text: 'O atendimento humanizado fez toda a diferença. Eles entenderam a linguagem do meu consultório e criaram um site limpo, sem poluição, que passa muita credibilidade aos meus pacientes.',
    location: 'Belo Horizonte, MG'
  },
  {
    name: 'Rodrigo Albuquerque',
    role: 'Diretor Comercial',
    business: 'Albuquerque & Associados',
    text: 'A agilidade da Ville studio é incomparável. Já trabalhamos com várias agências que demoravam semanas para mudar uma foto. Com eles, em poucas horas tudo estava pronto e funcionando perfeitamente.',
    location: 'Lisboa / Atendimento Internacional'
  }
];

export const FAQS: FAQItem[] = [
  {
    question: 'Como funciona a criação e entrega em até 2 horas?',
    answer: 'Temos uma metodologia refinada e ágil. Assim que você entra em contato pelo WhatsApp e compartilha as informações básicas (nome, serviços, fotos ou logo), nossa equipe entra em ação imediata em sprint dedicada. Em até 2 horas, seu site está desenhado, configurado e pronto para você aprovar e colocar no ar.'
  },
  {
    question: 'Vocês criam sites para qualquer tipo de nicho?',
    answer: 'Sim! Atendemos comércios locais, restaurantes, clínicas médicas, escritórios de advocacia, imobiliárias, barbearias, infoprodutores, lojas e profissionais autônomos. Adequamos a identidade visual e os textos de acordo com o perfil do seu cliente.'
  },
  {
    question: 'Vocês atendem apenas no Brasil ou também no exterior?',
    answer: 'Nosso atendimento é 100% digital, abrangendo clientes de todos os estados do Brasil e também no exterior (Portugal, Estados Unidos, Europa e América Latina).'
  },
  {
    question: 'O site funciona perfeitamente no celular?',
    answer: 'Com certeza. Desenvolvemos com foco prioritário em mobile (mobile-first), garantindo carregamento ultrarrápido, botões de toque confortáveis e perfeita legibilidade em qualquer smartphone ou computador.'
  },
  {
    question: 'Como solicito um orçamento ou tiro dúvidas?',
    answer: 'Basta clicar no botão "Solicitar Orçamento no WhatsApp" ou nos enviar uma mensagem diretamente no número (11) 99883-7294. Nosso atendimento é humanizado e respondemos em poucos minutos!'
  }
];
