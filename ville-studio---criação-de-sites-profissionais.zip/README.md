# Ville studio - Site Oficial

Site institucional moderno, minimalista e responsivo desenvolvido para a **Ville studio**.

## 🚀 Tecnologias Utilizadas
- **React 19**
- **Vite**
- **Tailwind CSS v4**
- **Lucide Icons**
- **TypeScript**

---

## 📦 Como Hospedar no Netlify

### Opção 1: Netlify Drop (Mais rápida - Sem código, em 30 segundos)
1. Acesse: [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Arraste a pasta `dist/` (ou descompacte o arquivo `ville-studio-dist.zip` e arraste seu conteúdo) para a tela do Netlify.
3. Seu site estará publicado imediatamente com HTTPS grátis!

### Opção 2: Conectar ao GitHub / Repositório
1. Suba este projeto para um repositório no seu GitHub.
2. No Netlify, clique em **Add new site** > **Import an existing project**.
3. Configure:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
4. Clique em **Deploy Site**.

---

## 🎨 Como Importar no Lovable
1. No Lovable, crie um novo projeto ou selecione **Import from GitHub** / **Upload Project**.
2. Carregue os arquivos do projeto (ou o repositório GitHub sincronizado).
3. O Lovable detectará automaticamente o framework Vite + React + Tailwind.

---

## 💻 Como Rodar Localmente no seu Computador
1. Certifique-se de ter o **Node.js** instalado (versão 18 ou superior).
2. No terminal, na pasta do projeto, instale as dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. Para gerar os arquivos finais de produção:
   ```bash
   npm run build
   ```
   Os arquivos prontos para qualquer servidor estarão na pasta `dist/`.
